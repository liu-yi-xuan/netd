# SPDX-FileCopyrightText: 2024-present liu-yi-xuan <53630521+liu-yi-xuan@users.noreply.github.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
