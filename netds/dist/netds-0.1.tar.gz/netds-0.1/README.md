# netds

[![PyPI - Version](https://img.shields.io/pypi/v/netds.svg)](https://pypi.org/project/netds)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/netds.svg)](https://pypi.org/project/netds)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install netds
```

## License

`netds` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
